typedef enum
{

} eAFTag;